/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: { colors: { ink: "#070914", electric: "#42B7FF", violet: "#7951E8" } } },
  plugins: []
};