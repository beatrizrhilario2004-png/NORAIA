import { useState } from "react";
import {
  ArrowDown, ArrowRight, ArrowUpRight, Atom, BarChart3, BriefcaseBusiness,
  Check, ChevronDown, Code2, Command, Cpu, Database, Fingerprint, Layers3,
  Menu, MessageSquareText, Network, PenTool, ShieldCheck, Sparkles, Workflow, X
} from "lucide-react";

const modules = [
  { name: "NORA ASSIST", tag: "Inteligência central", desc: "Conversas, explicações, estudos, textos e organização de ideias em um só lugar.", icon: MessageSquareText, tone: "blue" },
  { name: "NORA FLOW", tag: "Produtividade", desc: "Uma proposta para estruturar tarefas, conectar ferramentas e simplificar fluxos.", icon: Workflow, tone: "violet" },
  { name: "NORA SALES", tag: "Inteligência comercial", desc: "Apoio a estratégias de vendas, comunicação com clientes e oportunidades.", icon: BriefcaseBusiness, tone: "cyan" },
  { name: "NORA STUDIO", tag: "Criatividade", desc: "Ideias, roteiros, legendas e planejamento para desenvolver conteúdo.", icon: PenTool, tone: "pink" },
  { name: "NORA BUSINESS", tag: "Soluções empresariais", desc: "Organização administrativa, documentos, RH e processos de negócio.", icon: Layers3, tone: "violet" },
  { name: "NORA DATA", tag: "Dados e análise", desc: "Planilhas, relatórios, indicadores e identificação de padrões.", icon: BarChart3, tone: "blue" }
];

const faqs = [
  ["O que é a NORA IA?", "É um projeto de plataforma de inteligência artificial multifuncional criado para apoiar pessoas, profissionais e empresas em diferentes atividades."],
  ["A NORA IA já está disponível?", "A NORA IA está em desenvolvimento. Os módulos apresentados neste site representam a visão e o planejamento do projeto; não significam que os recursos já estejam disponíveis para uso."],
  ["Quem poderá utilizar a NORA IA?", "A proposta é atender pessoas, empreendedores, profissionais e empresas, com soluções pensadas para diferentes jornadas."],
  ["Quais soluções a plataforma pretende oferecer?", "A visão inclui conversação inteligente, produtividade, criação de conteúdo, apoio empresarial, inteligência comercial e análise de dados."],
  ["A NORA IA terá planos pagos?", "A estrutura comercial será definida conforme a evolução do projeto. Ainda não há preços ou planos ativos anunciados."],
  ["Como posso acompanhar o projeto?", "Você pode demonstrar interesse pelo formulário desta página. O envio real de dados será habilitado quando os canais e o backend oficiais estiverem configurados."]
];

function Logo() {
  return <a className="brand" href="#inicio" aria-label="NORA IA, início"><span className="brand-mark"><span>N</span></span><span>NORA<span className="brand-ai"> IA</span></span></a>;
}
function SectionLabel({ children }: { children: React.ReactNode }) {
  return <div className="eyebrow"><span className="eyebrow-line" />{children}</div>;
}
function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [interest, setInterest] = useState({ name: "", email: "", profile: "Pessoa física", message: "", consent: false });
  const [contact, setContact] = useState({ name: "", email: "", subject: "", message: "" });
  const [notice, setNotice] = useState("");

  const closeMenu = () => setMenuOpen(false);
  const submitUnavailable = (e: React.FormEvent) => {
    e.preventDefault();
    setNotice("Os campos foram validados no navegador, mas o cadastro ainda não foi enviado: o backend de recebimento não está conectado.");
  };

  return (
    <div className="site-shell">
      <header className="topbar">
        <div className="nav-wrap">
          <Logo />
          <button className="mobile-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}>{menuOpen ? <X /> : <Menu />}</button>
          <nav className={menuOpen ? "nav-links open" : "nav-links"}>
            {[["A NORA", "#historia"], ["Ecossistema", "#ecossistema"], ["Para quem", "#publico"], ["Nossa visão", "#visao"], ["Contato", "#contato"]].map(([label, href]) =>
              <a key={href} href={href} onClick={closeMenu}>{label}</a>
            )}
            <a className="nav-cta" href="#comunidade" onClick={closeMenu}>Acompanhar projeto <ArrowUpRight size={15} /></a>
          </nav>
        </div>
      </header>

      <main>
        <section className="hero section-pad" id="inicio">
          <div className="hero-grid" />
          <div className="hero-copy">
            <div className="status-pill"><span className="status-dot" /> UM NOVO CAPÍTULO EM INTELIGÊNCIA</div>
            <h1>O futuro da inteligência começa com <span>novas possibilidades.</span></h1>
            <p className="hero-lead">Conheça a NORA IA, uma plataforma criada para conectar pessoas, ideias e negócios ao potencial da inteligência artificial.</p>
            <p className="hero-sub">Uma nova maneira de pensar, criar, organizar e transformar possibilidades em resultados.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#historia">Conheça a NORA IA <ArrowRight size={17} /></a>
              <a className="button button-quiet" href="#ecossistema">Descubra nossas soluções <ArrowDown size={16} /></a>
            </div>
            <div className="hero-footnote"><span className="tiny-orbit" /> Tecnologia em construção. Possibilidades em expansão.</div>
          </div>
          <div className="hero-art" aria-label="Representação abstrata do núcleo de inteligência NORA">
            <div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="orbit orbit-three" />
            <div className="core-glow" /><div className="core"><span>N</span></div>
            <div className="orbit-node node-a" /><div className="orbit-node node-b" /><div className="orbit-node node-c" />
            <div className="art-label label-top"><span className="label-dot" /> NORA CORE <small>01 / INTELLIGENCE</small></div>
            <div className="art-label label-bottom"><small>IDEAS IN MOTION</small><span>∞</span></div>
            <div className="floating-chip chip-one"><Sparkles size={14} /> Ideias em evolução</div>
            <div className="floating-chip chip-two"><Network size={14} /> Conexões inteligentes</div>
          </div>
          <div className="hero-index">01 <span /> 11</div>
        </section>

        <section className="intro-strip"><div className="strip-inner"><span>INTELIGÊNCIA</span><i /> <span>CRIATIVIDADE</span><i /> <span>PRODUTIVIDADE</span><i /> <span>POSSIBILIDADES</span></div></section>

        <section className="story section-pad" id="historia">
          <div className="section-aside"><SectionLabel>01 — NOSSA HISTÓRIA</SectionLabel><span className="aside-note">UMA IDEIA.<br />NOVOS CAMINHOS.</span></div>
          <div className="story-content">
            <h2>Toda grande transformação começa com <em>uma ideia.</em></h2>
            <div className="story-columns">
              <p>A NORA IA nasceu de uma ideia simples, mas ambiciosa: tornar a inteligência artificial mais acessível, útil e presente na vida das pessoas.</p>
              <p>Acreditamos que existem milhares de pessoas com grandes ideias, empreendedores buscando oportunidades e empresas que desejam evoluir, mas que muitas vezes encontram dificuldades para transformar seus objetivos em realidade.</p>
              <p>Faltam tempo, recursos, organização ou acesso às ferramentas certas. Foi a partir dessa percepção que surgiu a proposta da NORA IA: desenvolver uma plataforma inteligente que ajude pessoas e empresas a superar desafios, encontrar soluções e explorar novas possibilidades.</p>
              <p>Queremos que a tecnologia seja uma ponte entre o que as pessoas imaginam e aquilo que podem realizar.</p>
            </div>
            <div className="quote-line"><span>“</span><p>Não queremos apenas acompanhar o futuro da inteligência artificial. Queremos ajudar a construir novas possibilidades com ela.</p></div>
          </div>
        </section>

        <section className="purpose section-pad">
          <div className="purpose-heading"><SectionLabel>02 — NOSSA DIREÇÃO</SectionLabel><h2>Uma tecnologia guiada<br />por <em>intenção.</em></h2></div>
          <div className="purpose-grid">
            {[["01", "Missão", "Democratizar o acesso à inteligência artificial, oferecendo soluções inteligentes que ajudem pessoas e empresas a trabalhar melhor, inovar, crescer e alcançar seus objetivos.", Fingerprint],
              ["02", "Visão", "Construir uma plataforma de inteligência artificial cada vez mais completa, acessível e confiável, capaz de apoiar diferentes necessidades pessoais e profissionais.", Atom],
              ["03", "Propósito", "Transformar tecnologia em oportunidades e inteligência em soluções reais.", Command]].map(([num, title, desc, Icon]) => {
                const I = Icon as typeof Fingerprint;
                return <article className="purpose-card" key={String(num)}><div className="card-top"><span>{String(num)}</span><I size={21} /></div><h3>{String(title)}</h3><p>{String(desc)}</p><div className="card-rule" /></article>;
              })}
          </div>
        </section>

        <section className="what section-pad">
          <div className="what-copy"><SectionLabel>03 — O QUE É A NORA IA?</SectionLabel><h2>Muito mais do que respostas. <em>Inteligência para possibilidades.</em></h2><p>A NORA IA está sendo pensada como uma plataforma multifuncional: um ambiente para reunir diferentes ferramentas inteligentes e apoiar pessoas em suas jornadas pessoais e profissionais.</p><a href="#ecossistema" className="text-link">Explore o ecossistema <ArrowUpRight size={16} /></a></div>
          <div className="audience-stack">
            {[["01", "Pessoas que desejam aprender e evoluir", "Conhecimento e organização para o cotidiano."], ["02", "Empreendedores com planos para tirar do papel", "Mais clareza para desenvolver ideias e negócios."], ["03", "Empresas que buscam evoluir processos", "Apoio para produtividade e organização."], ["04", "Profissionais e criadores em movimento", "Mais recursos para criar, planejar e realizar."]].map(item => <div className="audience-row" key={item[0]}><span>{item[0]}</span><div><h3>{item[1]}</h3><p>{item[2]}</p></div><ArrowUpRight size={17} /></div>)}
          </div>
        </section>

        <section className="ecosystem section-pad" id="ecossistema">
          <div className="ecosystem-head"><div><SectionLabel>04 — ECOSSISTEMA NORA</SectionLabel><h2>Um universo de soluções.<br /><em>Uma inteligência conectada.</em></h2></div><p>Uma visão modular, desenvolvida para crescer de acordo com as necessidades de quem usa.</p></div>
          <div className="module-grid">{modules.map((m, i) => { const Icon = m.icon; return <article className={`module-card ${m.tone}`} key={m.name}><div className="module-top"><span className="module-icon"><Icon size={21} /></span><span className="module-number">0{i + 1}</span></div><div className="module-tag">{m.tag}</div><h3>{m.name}</h3><p>{m.desc}</p><div className="module-bottom"><span className="dev-dot" /> MÓDULO PLANEJADO <ArrowUpRight size={15} /></div></article>; })}</div>
          <div className="transparency-note"><ShieldCheck size={18} /><p><strong>Transparência em cada etapa.</strong> Os módulos acima representam o ecossistema planejado da NORA IA. Eles ainda não devem ser considerados produtos ou funcionalidades disponíveis.</p></div>
        </section>

        <section className="forwho section-pad" id="publico">
          <div className="forwho-head"><SectionLabel>05 — PARA QUEM ESTAMOS CONSTRUINDO?</SectionLabel><h2>Inteligência que acompanha<br /><em>diferentes jornadas.</em></h2></div>
          <div className="forwho-grid">
            {[[Cpu, "Para pessoas", "Mais conhecimento, organização e possibilidades para o dia a dia."], [Sparkles, "Para empreendedores", "Apoio para transformar ideias em negócios, desenvolver estratégias e encontrar oportunidades."], [BriefcaseBusiness, "Para empresas", "Tecnologia para apoiar processos, produtividade, organização e crescimento."], [Code2, "Para profissionais", "Ferramentas inteligentes para otimizar tarefas e ampliar a capacidade de realização."]].map(([Icon, title, desc], i) => { const I = Icon as typeof Cpu; return <article className="forwho-card" key={String(title)}><div className="forwho-icon"><I size={22} /></div><span>0{i + 1}</span><h3>{String(title)}</h3><p>{String(desc)}</p></article>; })}
          </div>
        </section>

        <section className="principles section-pad">
          <div className="principles-title"><SectionLabel>06 — NOSSO DIFERENCIAL</SectionLabel><h2>Tecnologia com propósito.<br /><em>Inteligência com direção.</em></h2></div>
          <div className="principle-list">{[["01", "Acessibilidade", "Aproximar a inteligência artificial de mais pessoas."], ["02", "Versatilidade", "Desenvolver soluções para diferentes necessidades."], ["03", "Produtividade", "Ajudar a simplificar atividades e processos."], ["04", "Inovação", "Construir uma plataforma preparada para evoluir."], ["05", "Propósito", "Colocar a tecnologia a serviço das pessoas e dos negócios."]].map(x => <div className="principle-row" key={x[0]}><span>{x[0]}</span><h3>{x[1]}</h3><p>{x[2]}</p><ArrowUpRight size={16} /></div>)}</div>
        </section>

        <section className="future section-pad" id="visao">
          <div className="future-copy"><SectionLabel>07 — A VISÃO DE FUTURO</SectionLabel><h2>Estamos construindo<br />o <em>próximo passo.</em></h2><p>A NORA IA é um projeto em evolução. Nossa visão é desenvolver um ecossistema tecnológico cada vez mais integrado, capaz de reunir inteligência artificial, produtividade, criatividade, automação e soluções empresariais em uma única plataforma.</p><p>Queremos evoluir junto com nossos usuários, compreender suas necessidades e construir ferramentas que façam diferença na prática.</p></div>
          <div className="roadmap">
            <div className="roadmap-line" />
            {[["ETAPA 01", "Fundação", "Identidade, plataforma e núcleo de inteligência.", "Em planejamento"], ["ETAPA 02", "Expansão", "Novos módulos, ferramentas e recursos.", "Visão futura"], ["ETAPA 03", "Ecossistema", "Integrações, automações e soluções avançadas.", "Visão futura"]].map((x, i) => <div className="roadmap-item" key={x[0]}><div className="roadmap-marker">{String(i + 1).padStart(2, "0")}</div><div className="roadmap-info"><span>{x[0]}</span><h3>{x[1]}</h3><p>{x[2]}</p><small>{x[3]}</small></div></div>)}
            <p className="roadmap-disclaimer">Etapas ilustrativas do planejamento estratégico. Prazos e entregas ainda não anunciados.</p>
          </div>
        </section>

        <section className="community section-pad" id="comunidade">
          <div className="community-glow" />
          <div className="community-copy"><SectionLabel>08 — FAÇA PARTE</SectionLabel><h2>Faça parte dessa<br /><em>nova possibilidade.</em></h2><p>A NORA IA está sendo construída para pessoas que acreditam no poder das ideias, da tecnologia e da inovação. Queremos que você faça parte dessa jornada.</p><div className="community-caption"><span className="caption-line" /> GRANDES IDEIAS MERECEM INTELIGÊNCIA À ALTURA.</div></div>
          <form className="interest-form" onSubmit={submitUnavailable}>
            <div className="form-heading"><span>INTERESSE NO PROJETO</span><h3>Vamos manter contato?</h3><p>Deixe seus dados para demonstrar interesse.</p></div>
            <label>Nome<input required value={interest.name} onChange={e => setInterest({...interest, name:e.target.value})} placeholder="Como podemos chamar você?" /></label>
            <label>E-mail<input required type="email" value={interest.email} onChange={e => setInterest({...interest, email:e.target.value})} placeholder="voce@email.com" /></label>
            <label>Como você se identifica?<select value={interest.profile} onChange={e => setInterest({...interest, profile:e.target.value})}><option>Pessoa física</option><option>Empreendedor</option><option>Profissional</option><option>Empresa</option></select></label>
            <label>Mensagem <span className="optional">OPCIONAL</span><textarea rows={3} value={interest.message} onChange={e => setInterest({...interest, message:e.target.value})} placeholder="Conte um pouco sobre seu interesse..." /></label>
            <label className="consent"><input type="checkbox" required checked={interest.consent} onChange={e => setInterest({...interest, consent:e.target.checked})} /><span>Concordo em fornecer meus dados para contato sobre o projeto, conforme a política de privacidade.</span></label>
            <button className="button button-primary form-submit" type="submit">Enviar manifestação de interesse <ArrowRight size={16} /></button>
            <p className="form-privacy"><ShieldCheck size={14} /> O envio ficará disponível após a configuração segura do backend.</p>
            {notice && <p className="form-notice" role="status">{notice}</p>}
          </form>
        </section>

        <section className="faq section-pad">
          <div className="faq-heading"><SectionLabel>09 — DÚVIDAS FREQUENTES</SectionLabel><h2>Algumas respostas<br />para <em>começar.</em></h2></div>
          <div className="faq-list">{faqs.map(([q, a], i) => <div className={`faq-item ${openFaq === i ? "active" : ""}`} key={q}><button onClick={() => setOpenFaq(openFaq === i ? null : i)} aria-expanded={openFaq === i}><span className="faq-num">0{i + 1}</span><strong>{q}</strong><ChevronDown size={18} /></button>{openFaq === i && <p>{a}</p>}</div>)}</div>
        </section>

        <section className="contact section-pad" id="contato">
          <div className="contact-copy"><SectionLabel>10 — CONTATO</SectionLabel><h2>Vamos construir novas possibilidades <em>juntos?</em></h2><p>Tem uma ideia, uma pergunta ou interesse em colaborar com o projeto? Conte um pouco para nós.</p><div className="contact-placeholder"><span className="placeholder-icon"><MessageSquareText size={18} /></span><div><strong>Canais oficiais</strong><small>Serão divulgados em breve.</small></div></div></div>
          <form className="contact-form" onSubmit={submitUnavailable}>
            <label>Nome<input required value={contact.name} onChange={e => setContact({...contact, name:e.target.value})} placeholder="Seu nome" /></label>
            <label>E-mail<input required type="email" value={contact.email} onChange={e => setContact({...contact, email:e.target.value})} placeholder="voce@email.com" /></label>
            <label>Assunto<input required value={contact.subject} onChange={e => setContact({...contact, subject:e.target.value})} placeholder="Sobre o que deseja conversar?" /></label>
            <label>Mensagem<textarea required rows={4} value={contact.message} onChange={e => setContact({...contact, message:e.target.value})} placeholder="Escreva sua mensagem..." /></label>
            <button className="button button-outline" type="submit">Preparar contato <ArrowRight size={16} /></button>
            {notice && <p className="form-notice" role="status">{notice}</p>}
          </form>
        </section>
      </main>

      <footer className="footer">
        <div className="footer-main"><div><Logo /><p>Sua nova inteligência favorita.<br />Grandes ideias merecem inteligência à altura.</p></div><div className="footer-links"><div><span>EXPLORAR</span><a href="#historia">Nossa história</a><a href="#ecossistema">Ecossistema</a><a href="#visao">Visão de futuro</a></div><div><span>INFORMAÇÕES</span><a href="/privacidade.html">Privacidade</a><a href="/termos.html">Termos de uso</a><a href="#contato">Contato</a></div></div></div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} NORA IA. Todos os direitos reservados.</span><span>UM PROJETO EM EVOLUÇÃO <span className="footer-dot" /></span></div>
      </footer>
    </div>
  );
}
export default App;