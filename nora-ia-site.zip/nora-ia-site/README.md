# NORA IA — site institucional

Projeto inicial em React + TypeScript + Vite + Tailwind CSS, com identidade visual escura e responsiva.

## Executar localmente

```bash
npm install
npm run dev
```

## Gerar build

```bash
npm run build
npm run preview
```

## O que está implementado

- Landing page institucional com as seções do briefing.
- Navegação por âncoras e menu responsivo.
- Cards do ecossistema marcados como módulos planejados.
- FAQ interativo.
- Formulários com campos obrigatórios, validação nativa do navegador e aviso transparente.
- Metadados básicos de SEO e compartilhamento.
- Páginas provisórias de privacidade e termos.

## O que ainda depende de configuração

1. **Backend dos formulários:** conectar Supabase ou Lovable Cloud, criar tabelas e políticas RLS, validar no servidor e implementar proteção contra spam/rate limiting. Hoje os formulários NÃO enviam nem armazenam dados; exibem um aviso para não simular sucesso.
2. **LGPD:** completar a política com a identificação do controlador, finalidades, bases legais, retenção, compartilhamentos e canal de atendimento; revisar juridicamente antes de publicar.
3. **Termos:** completar e revisar juridicamente.
4. **Marca e canais:** inserir logotipo final, domínio, redes sociais e canais oficiais somente após confirmação.
5. **E-mail transacional:** configurar provedor e remetente verificado, se necessário.

## Observações

- Nenhuma chave ou credencial está incluída no frontend.
- Os módulos e etapas do roadmap são apresentados como planejamento, não como recursos já disponíveis.
- As páginas legais são rascunhos estruturais, não documentos jurídicos prontos.
